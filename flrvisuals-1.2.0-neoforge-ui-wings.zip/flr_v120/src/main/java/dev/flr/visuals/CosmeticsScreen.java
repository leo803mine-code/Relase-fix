package dev.flr.visuals;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.util.Mth;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.BooleanSupplier;
import java.util.function.Consumer;
import java.util.function.DoubleConsumer;
import java.util.function.DoubleFunction;
import java.util.function.DoubleSupplier;
import java.util.function.IntConsumer;
import java.util.function.IntSupplier;

public class CosmeticsScreen extends Screen {
    private static final String[] TABS = {"Cosmetics", "Effects", "Style", "Performance"};
    private static int tab;

    private static final class Row {
        String label;
        int type; // 0 toggle, 1 slider, 2 choice, 3 button
        BooleanSupplier bget; Consumer<Boolean> bset;
        double min, max; DoubleSupplier dget; DoubleConsumer dset; DoubleFunction<String> fmt;
        String[] opts; IntSupplier iget; IntConsumer iset;
        Runnable run;
        int y;
    }

    private final List<List<Row>> pages = new ArrayList<>();
    private int px, py, pw, ph, rx, rw, sidebar;
    private Row drag;
    private final Map<String, Float> toggleProgress = new HashMap<>();

    public CosmeticsScreen() { super(Component.literal("FLR VISUALS")); }

    private static Row toggle(String l, BooleanSupplier g, Consumer<Boolean> s) {
        Row r = new Row(); r.type = 0; r.label = l; r.bget = g; r.bset = s; return r;
    }
    private static Row slider(String l, double min, double max, DoubleSupplier g, DoubleConsumer s, DoubleFunction<String> f) {
        Row r = new Row(); r.type = 1; r.label = l; r.min = min; r.max = max; r.dget = g; r.dset = s; r.fmt = f; return r;
    }
    private static Row choice(String l, String[] o, IntSupplier g, IntConsumer s) {
        Row r = new Row(); r.type = 2; r.label = l; r.opts = o; r.iget = g; r.iset = s; return r;
    }
    private static Row button(String l, Runnable run) {
        Row r = new Row(); r.type = 3; r.label = l; r.run = run; return r;
    }

    @Override
    protected void init() {
        pages.clear();
        pw = Math.min(width - 20, 520);
        ph = Math.min(height - 20, 326);
        px = (width - pw) / 2;
        py = (height - ph) / 2;
        sidebar = Math.min(116, Math.max(88, pw / 4));
        rx = px + sidebar + 12;
        rw = pw - sidebar - 22;
        DoubleFunction<String> x2 = v -> String.format("%.2f", v);
        DoubleFunction<String> pct = v -> (int) Math.round(v * 100) + "%";

        pages.add(List.of(
                toggle("Halo", () -> Config.halo, v -> Config.halo = v),
                toggle("Wings", () -> Config.wings, v -> Config.wings = v),
                toggle("Cape", () -> Config.cape, v -> Config.cape = v),
                choice("Wing style", Config.WING_NAMES, () -> Config.wingStyle, v -> Config.wingStyle = v),
                slider("Wing size", 0.6, 1.8, () -> Config.wingSize, v -> Config.wingSize = v, x2),
                slider("Effect scale", 0.6, 1.6, () -> Config.scale, v -> Config.scale = v, x2),
                toggle("Show on other players", () -> Config.others, v -> Config.others = v)));
        pages.add(List.of(
                toggle("Particles", () -> Config.particles, v -> Config.particles = v),
                toggle("Aura", () -> Config.aura, v -> Config.aura = v),
                toggle("Trail", () -> Config.trail, v -> Config.trail = v),
                toggle("Hit sparks", () -> Config.hitSparks, v -> Config.hitSparks = v),
                toggle("Ambient fireflies", () -> Config.ambient, v -> Config.ambient = v),
                choice("Particle style", Config.PARTICLE_NAMES, () -> Config.particleType, v -> Config.particleType = v)));
        pages.add(List.of(
                choice("Theme", Config.THEME_NAMES, () -> Config.theme, v -> Config.theme = v),
                slider("Custom hue", 0, 360, () -> Config.hue, v -> Config.hue = v, v -> (int) v + "\u00b0"),
                slider("Animation speed", 0.2, 3, () -> Config.speed, v -> Config.speed = v, x2),
                slider("Fog tint", 0, 1, () -> Config.fogTint, v -> Config.fogTint = v, pct),
                slider("Fog density", 0, 1, () -> Config.fogDensity, v -> Config.fogDensity = v, pct)));
        pages.add(List.of(
                toggle("Auto performance", () -> Config.autoPerf, v -> Config.autoPerf = v),
                slider("Particle budget", 0, 200, () -> Config.particleBudget, v -> Config.particleBudget = (int) Math.round(v), v -> (int) v + "/s"),
                slider("Max distance", 8, 96, () -> Config.maxDistance, v -> Config.maxDistance = v, v -> (int) v + "m"),
                toggle("HUD badge", () -> Config.hud, v -> Config.hud = v),
                button("Preset: Minimal", () -> Config.preset(0)),
                button("Preset: Balanced", () -> Config.preset(1)),
                button("Preset: Max", () -> Config.preset(2)),
                button("Reset to defaults", Config::reset)));
    }

    @Override
    public void render(GuiGraphics g, int mx, int my, float pt) {
        int accent = 0xFF000000 | Config.color();
        int panel = 0xF00D0F18;
        int card = 0xFF171A27;
        int muted = 0xFF9298AD;
        g.fill(0, 0, width, height, 0xA8000000);
        // Layered panels create a rounded-card look without depending on extra textures.
        g.fill(px - 1, py - 1, px + pw + 1, py + ph + 1, 0xFF05060B);
        g.fill(px, py, px + pw, py + ph, panel);
        g.fill(px, py, px + pw, py + 2, accent);
        g.fill(px + 1, py + 1, px + pw - 1, py + 42, 0xFF111421);
        g.fill(px + 1, py + 42, px + pw - 1, py + 43, 0xFF292D40);
        g.drawString(font, "FLR", px + 14, py + 10, accent, true);
        g.drawString(font, "VISUALS", px + 40, py + 10, 0xFFFFFFFF, true);
        g.drawString(font, "CLIENT COSMETICS  /  1.2.0", px + 14, py + 25, muted, false);
        g.fill(px + pw - 72, py + 11, px + pw - 13, py + 30, 0xFF202538);
        g.drawCenteredString(font, Config.master ? "● ACTIVE" : "○ OFF", px + pw - 42, py + 17, Config.master ? accent : muted);

        for (int i = 0; i < TABS.length; i++) {
            int ty = py + 53 + i * 30;
            boolean sel = i == tab;
            g.fill(px + 8, ty, px + sidebar - 8, ty + 25, sel ? 0xFF28243A : 0xFF11131D);
            if (sel) {
                g.fill(px + 8, ty, px + 11, ty + 25, accent);
                g.fill(px + 11, ty + 24, px + sidebar - 8, ty + 25, accent);
            }
            g.drawString(font, tabIcon(i) + "  " + TABS[i], px + 17, ty + 8, sel ? 0xFFFFFFFF : muted, false);
        }
        g.drawString(font, "NEOFORGE 1.21.1", px + 12, py + ph - 17, 0xFF626A80, false);

        int y = py + 51;
        int rowH = 24;
        for (Row r : pages.get(tab)) {
            r.y = y;
            boolean hover = mx >= rx && mx <= rx + rw && my >= y && my <= y + rowH;
            g.fill(rx, y, rx + rw, y + rowH, hover ? 0xFF202438 : card);
            g.fill(rx, y, rx + 2, y + rowH, hover ? accent : 0xFF292D3D);
            if (r.type == 3) {
                g.drawCenteredString(font, r.label, rx + rw / 2, y + 8, 0xFFE8E9F3);
            } else {
                g.drawString(font, r.label, rx + 9, y + 8, 0xFFE8E9F3, false);
                int cx = rx + rw - 9;
                if (r.type == 0) {
                    boolean on = r.bget.getAsBoolean();
                    float target = on ? 1f : 0f;
                    float progress = toggleProgress.getOrDefault(r.label, target);
                    progress += (target - progress) * 0.28f;
                    if (Math.abs(target - progress) < 0.015f) progress = target;
                    toggleProgress.put(r.label, progress);
                    int left = cx - 35;
                    g.fill(left, y + 5, cx, y + 19, blend(0xFF34394B, accent, progress));
                    int knobX = left + 1 + Math.round(progress * 21f);
                    g.fill(knobX, y + 6, knobX + 12, y + 18, 0xFFF3F3FA);
                    g.drawString(font, on ? "ON" : "OFF", left - 25, y + 8, on ? accent : muted, false);
                } else if (r.type == 1) {
                    int bx = rx + rw / 2, bw = Math.max(30, rw / 2 - 14);
                    double f = Mth.clamp((r.dget.getAsDouble() - r.min) / (r.max - r.min), 0, 1);
                    g.fill(bx, y + 16, bx + bw, y + 18, 0xFF393D50);
                    g.fill(bx, y + 16, bx + (int) (bw * f), y + 18, accent);
                    g.fill(bx + (int) (bw * f) - 3, y + 13, bx + (int) (bw * f) + 3, y + 21, 0xFFF3F3FA);
                    String value = r.fmt.apply(r.dget.getAsDouble());
                    g.drawString(font, value, rx + rw - font.width(value) - 8, y + 3, accent, false);
                } else {
                    int idx = Mth.clamp(r.iget.getAsInt(), 0, r.opts.length - 1);
                    String value = "‹  " + r.opts[idx] + "  ›";
                    g.drawString(font, value, cx - font.width(value), y + 8, accent, false);
                }
            }
            y += 27;
        }
        super.render(g, mx, my, pt);
    }

    private static String tabIcon(int i) {
        return switch (i) { case 0 -> "✦"; case 1 -> "◈"; case 2 -> "◉"; default -> "⚙"; };
    }

    private static int blend(int a, int b, float t) {
        int aa = (a >>> 24) & 255, ar = (a >>> 16) & 255, ag = (a >>> 8) & 255, ab = a & 255;
        int ba = (b >>> 24) & 255, br = (b >>> 16) & 255, bg = (b >>> 8) & 255, bb = b & 255;
        int alpha = Mth.clamp(Math.round(Mth.lerp(t, aa, ba)), 0, 255);
        int red = Mth.clamp(Math.round(Mth.lerp(t, ar, br)), 0, 255);
        int green = Mth.clamp(Math.round(Mth.lerp(t, ag, bg)), 0, 255);
        int blue = Mth.clamp(Math.round(Mth.lerp(t, ab, bb)), 0, 255);
        return (alpha << 24) | (red << 16) | (green << 8) | blue;
    }

    private void applySlider(Row r, double mouseX) {
        int bx = rx + rw / 2, bw = Math.max(30, rw / 2 - 14);
        double f = Mth.clamp((mouseX - bx) / bw, 0, 1);
        r.dset.accept(r.min + (r.max - r.min) * f);
    }

    @Override
    public boolean mouseClicked(double mx, double my, int btn) {
        for (int i = 0; i < TABS.length; i++) {
            int ty = py + 53 + i * 30;
            if (mx >= px + 8 && mx <= px + sidebar - 8 && my >= ty && my <= ty + 25) { tab = i; return true; }
        }
        for (Row r : pages.get(tab)) {
            if (mx < rx || mx > rx + rw || my < r.y || my > r.y + 24) continue;
            switch (r.type) {
                case 0 -> r.bset.accept(!r.bget.getAsBoolean());
                case 1 -> { drag = r; applySlider(r, mx); }
                case 2 -> {
                    int n = r.opts.length;
                    r.iset.accept(Math.floorMod(r.iget.getAsInt() + (btn == 1 ? -1 : 1), n));
                }
                default -> r.run.run();
            }
            Config.save();
            return true;
        }
        return super.mouseClicked(mx, my, btn);
    }

    @Override
    public boolean mouseDragged(double mx, double my, int btn, double dx, double dy) {
        if (drag != null) { applySlider(drag, mx); return true; }
        return super.mouseDragged(mx, my, btn, dx, dy);
    }

    @Override
    public boolean mouseReleased(double mx, double my, int btn) {
        if (drag != null) { drag = null; Config.save(); }
        return super.mouseReleased(mx, my, btn);
    }

    @Override
    public void onClose() { Config.save(); super.onClose(); }

    @Override
    public boolean isPauseScreen() { return false; }
}
