FLR Visuals 1.2.0 — NeoForge 1.21.1

Build a JAR with GitHub Actions:
1. Upload this project folder's CONTENTS to a new GitHub repository.
2. Open the Actions tab and enable workflows if GitHub asks.
3. Open the workflow named "build" and press "Run workflow" (or push a commit).
4. When it finishes successfully, open the run and download the "flrvisuals" artifact.
5. The artifact contains the built JAR. Put it in your Minecraft instance's mods folder with NeoForge 1.21.1.

Menu key: Right Shift. Master toggle: configured key mapping.
Cosmetics: Angel, Demon, Dark, Crystal and Energy wing styles.

Important: the source was updated, but this environment does not have Gradle installed,
so the final Minecraft build must be confirmed by the GitHub Actions result before use.
